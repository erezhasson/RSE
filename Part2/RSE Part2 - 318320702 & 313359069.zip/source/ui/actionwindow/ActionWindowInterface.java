package ui.actionwindow;

import javafx.scene.control.TableColumn;

public interface ActionWindowInterface {

    <T> void loadActionWindowInfo(T windowInfo);
}
