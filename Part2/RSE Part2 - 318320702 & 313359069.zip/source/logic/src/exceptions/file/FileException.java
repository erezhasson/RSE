package exceptions.file;

public class FileException extends Exception{
}
