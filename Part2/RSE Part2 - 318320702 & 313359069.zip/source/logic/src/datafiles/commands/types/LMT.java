package datafiles.commands.types;

public class LMT extends CommandType{
}
