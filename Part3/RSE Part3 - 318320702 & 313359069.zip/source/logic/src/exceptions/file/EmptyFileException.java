package exceptions.file;

public class EmptyFileException extends Exception{
}
