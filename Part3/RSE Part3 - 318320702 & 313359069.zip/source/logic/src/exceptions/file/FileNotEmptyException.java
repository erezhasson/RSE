package exceptions.file;

public class FileNotEmptyException extends FileException{
}
