package datafiles.commands.types;

public class FOK extends CommandType{
}
