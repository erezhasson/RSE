package datafiles.commands.types;

public class IOC extends CommandType{
}
