package datafiles.commands.types;

public class MKT extends CommandType{
}
