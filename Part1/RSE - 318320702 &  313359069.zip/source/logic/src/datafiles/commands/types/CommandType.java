package datafiles.commands.types;

public abstract class CommandType {
}
